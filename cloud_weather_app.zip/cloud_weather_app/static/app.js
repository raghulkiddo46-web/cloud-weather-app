const form = document.getElementById("search-form");
const input = document.getElementById("city-input");
const message = document.getElementById("message");
const content = document.getElementById("weather-content");
const searchButton = document.getElementById("search-button");

const weatherMap = {
  0: ["Clear sky", "☀️"], 1: ["Mainly clear", "🌤️"], 2: ["Partly cloudy", "⛅"],
  3: ["Overcast", "☁️"], 45: ["Fog", "🌫️"], 48: ["Depositing rime fog", "🌫️"],
  51: ["Light drizzle", "🌦️"], 53: ["Drizzle", "🌦️"], 55: ["Heavy drizzle", "🌧️"],
  56: ["Freezing drizzle", "🌧️"], 57: ["Freezing drizzle", "🌧️"],
  61: ["Slight rain", "🌦️"], 63: ["Moderate rain", "🌧️"], 65: ["Heavy rain", "🌧️"],
  66: ["Freezing rain", "🌧️"], 67: ["Heavy freezing rain", "🌧️"],
  71: ["Slight snowfall", "🌨️"], 73: ["Moderate snowfall", "🌨️"], 75: ["Heavy snowfall", "❄️"],
  77: ["Snow grains", "❄️"], 80: ["Rain showers", "🌦️"], 81: ["Rain showers", "🌧️"],
  82: ["Violent rain showers", "⛈️"], 85: ["Snow showers", "🌨️"], 86: ["Heavy snow showers", "❄️"],
  95: ["Thunderstorm", "⛈️"], 96: ["Thunderstorm with hail", "⛈️"], 99: ["Thunderstorm with hail", "⛈️"]
};

function weatherInfo(code) {
  return weatherMap[code] || ["Weather conditions", "🌤️"];
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.classList.toggle("error", isError);
  message.classList.remove("hidden");
}

function formatDay(dateString, index) {
  if (index === 0) return "Today";
  if (index === 1) return "Tomorrow";
  return new Date(`${dateString}T12:00:00`).toLocaleDateString(undefined, { weekday: "short" });
}

function formatTime(value) {
  if (!value) return "--:--";
  return value.split("T")[1] || value;
}

async function loadWeather(city) {
  if (!city.trim()) return;
  searchButton.disabled = true;
  searchButton.textContent = "Loading…";
  content.classList.add("hidden");
  showMessage(`Getting weather for ${city}…`);
  try {
    const response = await fetch(`/api/weather?city=${encodeURIComponent(city)}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Unable to load weather.");
    renderWeather(data);
    message.classList.add("hidden");
    content.classList.remove("hidden");
  } catch (error) {
    showMessage(error.message || "Something went wrong. Please try again.", true);
  } finally {
    searchButton.disabled = false;
    searchButton.innerHTML = 'Search <span>→</span>';
  }
}

function renderWeather(data) {
  const c = data.current;
  const d = data.daily;
  const place = data.location;
  const [condition, icon] = weatherInfo(c.weather_code);

  document.getElementById("place-name").textContent = place.name;
  document.getElementById("place-meta").textContent = [place.admin1, place.country].filter(Boolean).join(", ");
  document.getElementById("local-time").textContent = `Local time · ${place.timezone || "Local timezone"}`;
  document.getElementById("current-icon").textContent = icon;
  document.getElementById("temperature").textContent = Math.round(c.temperature_2m);
  document.getElementById("condition").textContent = condition;
  document.getElementById("feels-like").textContent = Math.round(c.apparent_temperature);
  document.getElementById("humidity").textContent = `${c.relative_humidity_2m}%`;
  document.getElementById("wind").textContent = `${c.wind_speed_10m} km/h`;
  document.getElementById("precipitation").textContent = `${c.precipitation} mm`;
  document.getElementById("sunrise").textContent = formatTime(d.sunrise[0]);
  document.getElementById("sunset").textContent = formatTime(d.sunset[0]);
  document.getElementById("range").textContent = `${Math.round(d.temperature_2m_min[0])}° / ${Math.round(d.temperature_2m_max[0])}°C`;

  const grid = document.getElementById("forecast-grid");
  grid.replaceChildren();
  d.time.forEach((day, i) => {
    const [label, emoji] = weatherInfo(d.weather_code[i]);
    const card = document.createElement("article");
    card.className = "forecast-day";
    const dayName = document.createElement("strong");
    dayName.textContent = formatDay(day, i);
    const iconEl = document.createElement("span");
    iconEl.className = "forecast-icon";
    iconEl.textContent = emoji;
    iconEl.setAttribute("aria-label", label);
    const desc = document.createElement("small");
    desc.textContent = label;
    const temps = document.createElement("div");
    temps.className = "forecast-temps";
    const high = document.createElement("b");
    high.textContent = `${Math.round(d.temperature_2m_max[i])}°`;
    const low = document.createElement("span");
    low.textContent = `${Math.round(d.temperature_2m_min[i])}°`;
    temps.append(high, low);
    card.append(dayName, iconEl, desc, temps);
    grid.append(card);
  });
}

form.addEventListener("submit", event => {
  event.preventDefault();
  loadWeather(input.value);
});
document.querySelectorAll(".city-chip").forEach(button => {
  button.addEventListener("click", () => {
    input.value = button.dataset.city;
    loadWeather(button.dataset.city);
  });
});
loadWeather("Chennai");
