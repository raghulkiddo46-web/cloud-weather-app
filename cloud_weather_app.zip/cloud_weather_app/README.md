# Cloud-Based Weather Application

A responsive weather dashboard built with Flask, HTML, CSS and JavaScript. It uses the free Open-Meteo geocoding and forecast APIs; no API key is required.

## Features
- Search for a city worldwide
- Current temperature and feels-like temperature
- Weather condition and day/night indicator
- Humidity, wind speed and precipitation
- Seven-day forecast with high/low temperatures
- Sunrise and sunset times
- Responsive dashboard for mobile and desktop
- Health endpoint for cloud deployment checks
- Docker and Render deployment configuration

## Requirements
- Python 3.9+
- Internet connection (the app calls Open-Meteo APIs)

## Run locally on Windows
1. Extract the ZIP.
2. Open the folder in VS Code or Command Prompt.
3. Create a virtual environment:
   `python -m venv venv`
4. Activate it:
   `venv\\Scripts\\activate`
5. Install dependencies:
   `pip install -r requirements.txt`
6. Run:
   `python app.py`
7. Open `http://127.0.0.1:5000`.

## Deploy to Render
1. Create a GitHub account if you do not have one.
2. Create a new GitHub repository and upload this project's files.
3. Sign in to Render and choose **New + → Blueprint**.
4. Connect the GitHub repository containing `render.yaml`.
5. Review the service settings and deploy.
6. Open the public URL provided by Render.

The `Procfile` is also included for platforms that support it. The Dockerfile can be used on Docker-compatible cloud hosting.

## API and data
- Geocoding: `https://geocoding-api.open-meteo.com/v1/search`
- Forecast: `https://api.open-meteo.com/v1/forecast`
- Provider: Open-Meteo (see https://open-meteo.com/ for API terms and attribution requirements).

## Project structure
```
cloud_weather_app/
|-- app.py
|-- requirements.txt
|-- Procfile
|-- render.yaml
|-- Dockerfile
|-- README.md
|-- .gitignore
|-- templates/
|   |-- index.html
|-- static/
    |-- style.css
    |-- app.js
```

## Academic project note
This is a cloud-deployable student project starter. A live internet connection is needed to retrieve weather data. Cloud deployment is not performed automatically by running the app locally; follow the Render steps above.
