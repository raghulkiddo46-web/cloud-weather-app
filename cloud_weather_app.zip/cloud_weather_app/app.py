from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

GEO_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/weather")
def weather():
    city = request.args.get("city", "").strip()
    if not city:
        return jsonify({"error": "Please enter a city name."}), 400

    try:
        geo_response = requests.get(
            GEO_URL,
            params={"name": city, "count": 1, "language": "en", "format": "json"},
            timeout=10
        )
        geo_response.raise_for_status()
        geo_data = geo_response.json()
        results = geo_data.get("results", [])
        if not results:
            return jsonify({"error": f"No location found for '{city}'."}), 404

        place = results[0]
        params = {
            "latitude": place["latitude"],
            "longitude": place["longitude"],
            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m",
            "daily": "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max",
            "timezone": "auto",
            "forecast_days": 7
        }
        forecast_response = requests.get(FORECAST_URL, params=params, timeout=10)
        forecast_response.raise_for_status()
        data = forecast_response.json()

        return jsonify({
            "location": {
                "name": place.get("name"),
                "admin1": place.get("admin1", ""),
                "country": place.get("country", ""),
                "timezone": data.get("timezone", "")
            },
            "current": data.get("current", {}),
            "daily": data.get("daily", {}),
            "units": {
                "current": data.get("current_units", {}),
                "daily": data.get("daily_units", {})
            }
        })
    except requests.RequestException:
        return jsonify({"error": "Weather service is temporarily unavailable. Please try again."}), 502
    except (KeyError, ValueError):
        return jsonify({"error": "Unexpected weather data received. Please try another city."}), 502

@app.route("/health")
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port= int(__import__("os").environ.get("PORT", 5000)), debug=False)
